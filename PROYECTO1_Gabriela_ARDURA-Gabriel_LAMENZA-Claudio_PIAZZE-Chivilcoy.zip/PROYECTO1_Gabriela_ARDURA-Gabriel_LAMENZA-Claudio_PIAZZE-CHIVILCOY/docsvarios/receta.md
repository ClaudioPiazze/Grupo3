## Base de datos utilizada: Presndas.json

### --------------------desde cero----------------------------------------------------------
1. crear cluster
2. mongodb compass -->subir el json y armar la bbdd
3. VSCode --> crear un proyecto

### ------------------- cuando descomprimis el archivo del pryecto--------------------------
1. terminal --> **npm** init -y.
2. terminal --> **npm** install express 
3. terminal --< **npm** install mongodb
4. terminal --> **npm** install dotenv

### ------------------ para cuando inicias el proyecto--------------------------------------
1. crear los archivos .js -- uno el server.js y otro para ./src/mongodb.js
2. pegar esta linea en el package.json   "start": "node --watch server.js"
3. crear las apis
4. probar en postman o thunder cada API



